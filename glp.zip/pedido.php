<?php
session_start();
require_once('conexion.php');

date_default_timezone_set("America/Santiago");
$hora = time(); 
$fec_sol = date('Y-m-d H:i:s',$hora);



$idgas=$_POST['idgas'];
//$terminos=$_POST['terminos'];
$idusu=$_POST['idusuario'];


               $sqlSolicitarPedido="insert into solicitud (cliente_id, fec_solicitud, producto_id) values ('$idusu','$fec_sol','$idgas')"; 
               $ejecSolicitarPedido=mysql_query($sqlSolicitarPedido, $conexion);

    

?>
        <script>
           window.location.href = "listado.php";
        </script>