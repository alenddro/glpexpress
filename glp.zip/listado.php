<?php session_start();
require_once('conexion.php');


        if ($_SESSION['esadmin']==0) {
           
             //id usuario logueado
            $sqlIDusuarioLogueado="select * from usuario where nombreusu='$_SESSION[nombreusu]'";
            $ejecIDusuarioLogueado=mysql_query($sqlIDusuarioLogueado, $conexion);
            $arrayIDusuarioLogueado=mysql_fetch_array($ejecIDusuarioLogueado);

            $cliid=$arrayIDusuarioLogueado['id'];

             //mis solicitudes
            $sqlSolicitud="select producto.*, solicitud.* from solicitud, producto where solicitud.cliente_id='$cliid' and producto.id=solicitud.producto_id order by solicitud.fec_solicitud desc";
            $ejecSolicitud=mysql_query($sqlSolicitud, $conexion);

        }elseif($_SESSION['esadmin']==1){

             //id usuario logueado
            $sqlIDusuarioLogueado="select * from usuario";
            $ejecIDusuarioLogueado=mysql_query($sqlIDusuarioLogueado, $conexion);
            $arrayIDusuarioLogueado=mysql_fetch_array($ejecIDusuarioLogueado);

            $cliid=$arrayIDusuarioLogueado['id'];

             //mis solicitudes
            $sqlSolicitud="select producto.*, solicitud.* from solicitud, producto where producto.id=solicitud.producto_id order by solicitud.fec_solicitud desc";
            $ejecSolicitud=mysql_query($sqlSolicitud, $conexion);

        }






        
       
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registro | GLPEXPRESS</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
    <header>
        <div class="navbar navbar-inverse" id="nav-lipigas" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.html">GLP EXPRESS</a>
            </div>
            <div class="collapse navbar-collapse">
              <ul class="nav navbar-nav">
                <li class="active"><a href="index.html">Home</a></li>
                <li><a href="index.html">Acerca de</a></li>
                <li><a href="index.html">Solicite Pedido</a></li>
              </ul>
            </div><!--/.nav-collapse -->
          </div>
        </div>
    </header>
         <a href="cierra_session.php">Cerrar Sesion</a>
         <a href="solicita.php">Regresar a Solicitudes</a>
    <div class="jumbotron" id="formulario-registro">
        <section id="principal-registro" class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="starter-template hidden-xs">
                                    <h1></h1>
                                    <p class="lead">Bienvenido al Listado de Solicitudes <i><strong><?php echo $_SESSION['nombreusu']?></strong></i></p>
                                 </div>
                                 <div class="starter-template visible-xs-block hidden-lg hidden-md hidden-sm">
                                    <h2>Bienvenido al Listado de Solicitudes</h2>
                                     
                                 </div>
                            </div><!-- /.container -->      


                            <section class="container-fluid">   
                                <div class="row">
                                    <div class="col-xs-12 col-md-12 ">
                                        <article class="container">
                                            <div class="container-fluid">  
                                                <div class="row">
                                                    <div class="col-xs-12 head-registro">
                                                         <h2 class="form-signin-heading">&nbsp;</h2>
                                                    </div>
                                                </div>
                                            </div>
                                            <form class="form-signin registro-lipigas-listado" role="form" id="listadogas">
                                               <?php
                                                if ($_SESSION['esadmin']==0) {       
                                                    while($arraySolicitud=mysql_fetch_array($ejecSolicitud)){

                                                        
                                                   ?>
                                                    <div class="col-xs-12" style="background:yellow;opacity:0.4; font-size:20px; padding:10px;color:black;margin-top:5px;">
                                                        <?php echo $arraySolicitud['fec_solicitud'];?>  &nbsp;  <?php echo $arraySolicitud['nombre']; ?>&nbsp;  ACTIVA
                                                    </div>
                                                    <br>
                                                   <?php  
                                                    }
                                                }elseif($_SESSION['esadmin']==1){
                                                    while($arraySolicitud=mysql_fetch_array($ejecSolicitud)){

                                                        
                                                       ?>
                                                     <a href="versolicitud.php?l=<?php echo $arraySolicitud['id']?>" onclick="listadogas.submit();">
                                                        <div class="col-xs-12" style="background:yellow;opacity:0.4;font-size:20px; padding:10px;color:black;margin-top:5px;">
                                                            <?php echo $arraySolicitud['fec_solicitud'];?>  &nbsp;  <?php echo $arraySolicitud['nombre']; ?>&nbsp;  ACTIVA
                                                        </div>
                                                        <input type="hidden" value="">
                                                     </a>  
                                                        <br>
                                                       <?php  
                                                    }
                                                }    
                                                    ?> 

                                            </form>

                                        </article>
                                    </div>
                                </div>
                            </section>  
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <footer class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 text-center">
                            <p>Sucursal Lipigas &copy; Company 2014</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>