
<?php
session_start();
require_once('conexion.php');
   


    $idsol=$_GET['l'];

    $sqlSolicitudDatos="select * from solicitud, usuario, producto where solicitud.id='$idsol' and usuario.id=solicitud.cliente_id and producto.id=solicitud.producto_id";
    $ejecSolicitudDatos=mysql_query($sqlSolicitudDatos);
    $arraySolicitudDatos=mysql_fetch_array($ejecSolicitudDatos);
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modificar | GLPEXPRESS</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
    <header>
        <div class="navbar navbar-inverse" id="nav-lipigas" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.html">GLP EXPRESS</a>
            </div>
            <div class="collapse navbar-collapse">
              <ul class="nav navbar-nav">
                <li class="active"><a href="index.html">Home</a></li>
                <li><a href="index.html">Acerca de</a></li>
                <li><a href="index.html">Solicite Pedido</a></li>
              </ul>
            </div><!--/.nav-collapse -->
          </div>
        </div>
    </header>

    <div class="jumbotron" id="formulario-registro">
        <section id="principal-registro" class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="starter-template hidden-xs">
                                    <h1>Solicitud numero: <?php echo $idsol;?></h1>
                                    <p class="lead"></p>
                                 </div>
                                 <div class="starter-template visible-xs-block hidden-lg hidden-md hidden-sm">
                                    <h2></h2>
                                     
                                 </div>
                            </div><!-- /.container -->      


                            <section class="container-fluid">   
                                <div class="row">
                                    <div class="col-xs-12 col-md-12 ">
                                        <article class="container">
                                            <div class="container-fluid">  
                                                <div class="row">
                                                    <div class="col-xs-12 head-registro">
                                                         <h2 class="form-signin-heading">Datos de la Solicitud</h2>
                                                    </div>
                                                </div>
                                            </div>
                                            <form class="form-signin registro-lipigas" role="form" method="post" action="registrar.php">
                                                <label>Nombre</label>
                                                <input  value="<?php echo $arraySolicitudDatos[7]?>" type="text" disabled name="nombreusu" class="form-control"  required="" autofocus="">
                                                <br>
                                                <label>Apellido</label>
                                                <input  value="<?php echo $arraySolicitudDatos['apellido']?>" type="text" disabled name="password" class="form-control" required="">
                                                <br>
                                                <label>Direccion</label>
                                                <input  value="<?php echo $arraySolicitudDatos['direccion']?>" type="text" disabled name="reppassword" class="form-control" required="">
                                                <br>
                                                <label>Telefono</label>
                                                <input  value="<?php echo $arraySolicitudDatos['telefono']?>" type="text" disabled name="direccion" class="form-control" required="" autofocus="">
                                                <br>
                                                <label>Detalle</label>
                                                <input  value="<?php echo $arraySolicitudDatos[15]?>" type="text" disabled name="nombre" class="form-control" required="" autofocus="">
                                                <br>
                                                <label>Valor</label>
                                                <input  value="$<?php echo $arraySolicitudDatos['valor']?>" type="text" disabled name="email" class="form-control" required="" autofocus="">
                                                <br>
                                                <label>Fecha/Hora Solicitud</label>
                                                <input  value="<?php echo $arraySolicitudDatos['fec_solicitud']?>" type="tel" name="text" disabled class="form-control" required="" autofocus="">
                                                <br>
                                            </form>

                                        </article>
                                    </div>
                                </div>
                            </section>  
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <footer class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 text-center">
                            <p>Sucursal Lipigas &copy; Company 2014</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>