<?php
$conexion = mysql_connect('mysql.hostinger.es', 'u318767762_glpex', 'Administrad0r');
mysql_select_db('u318767762_glpex') or die("No se puede seleccionar la base de datos de desarrollo");

?>