<?php include 'contador.php'; ?>
<h1>Contador</h1>
<?php include 'mostra_contador.php'; ?>