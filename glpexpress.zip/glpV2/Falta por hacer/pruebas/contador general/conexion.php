<?php
$conexion = mysql_connect('localhost', 'root', '');
mysql_select_db('contador') or die("No se puede seleccionar la base de datos de desarrollo");

?>