<footer class="container-fluid footer">
	<div class="row">
		<div class="col-xs-12">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 text-center">
    					<h1>&copy; GlpExpress 2015</h1>
						<p>Nosotros | Privacidad | Terminos y condiciones</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>